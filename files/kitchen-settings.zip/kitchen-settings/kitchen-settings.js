
if(Meteor.isServer)
{
  app_json=JSON.parse(Assets.getText('application.json'));
  Meteor.methods({
    'get_app_json':function() { 
      return app_json;
    }
  });
} else if (Meteor.isClient) {
  dep = new Tracker.Dependency;

  app_json={
    isReady: function(){
      //Reactive ready method
      dep.depend();
    },
    get: function() {
      //Reactive get method
      dep.depend();
      return app_json.application;
    }
  }
  Meteor.call('get_app_json', function(error,result){
    if(error){
      console.error("kitchen-settings: error getting app_json: ", error )
      return
    }
    var call_changed=false
    if(dep.hasDependents()){
      if(!EJSON.equals( result.application, app_json.application)) {
         call_changed=true;
      }
    }
    _.extend(app_json,result)
    if(call_changed) dep.changed();

  });
  
}